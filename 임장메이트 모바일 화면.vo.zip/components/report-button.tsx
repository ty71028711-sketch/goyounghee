"use client"

import { FileText, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useState } from "react"

export function ReportButton() {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <Button
      size="lg"
      className="relative gap-2 overflow-hidden bg-accent px-6 text-accent-foreground shadow-lg transition-all hover:bg-accent/90 hover:shadow-xl"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {isHovered ? (
        <Sparkles className="size-4.5 animate-pulse" />
      ) : (
        <FileText className="size-4.5" />
      )}
      <span className="font-semibold">{"임장메이트PRO 리포트 생성"}</span>
    </Button>
  )
}
