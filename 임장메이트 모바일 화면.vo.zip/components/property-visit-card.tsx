"use client"

import { Clock, Phone, MapPin, Building, Users, CheckCircle2, Circle, AlertCircle } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export interface PropertyVisit {
  id: number
  apartmentName: string
  dong: string
  ho: string
  price: string
  priceType: string
  visitTime: string
  appointmentStatus: "확정" | "미확정" | "변경요청"
  coBrokerAgency: string
  visitPhone: string
  agencyPhone: string
  memo?: string
}

function StatusIcon({ status }: { status: PropertyVisit["appointmentStatus"] }) {
  switch (status) {
    case "확정":
      return <CheckCircle2 className="size-3.5 text-emerald-600" />
    case "미확정":
      return <Circle className="size-3.5 text-amber-500" />
    case "변경요청":
      return <AlertCircle className="size-3.5 text-red-500" />
  }
}

function statusBadgeClass(status: PropertyVisit["appointmentStatus"]) {
  switch (status) {
    case "확정":
      return "border-emerald-200 bg-emerald-50 text-emerald-700"
    case "미확정":
      return "border-amber-200 bg-amber-50 text-amber-700"
    case "변경요청":
      return "border-red-200 bg-red-50 text-red-700"
  }
}

export function PropertyVisitCard({ visit, index }: { visit: PropertyVisit; index: number }) {
  return (
    <Card className="group border-border/80 py-0 shadow-sm transition-all hover:border-accent/30 hover:shadow-md">
      {/* Top colored bar */}
      <div className="h-1 rounded-t-xl bg-primary" />

      <CardContent className="p-0">
        {/* Header row */}
        <div className="flex items-start justify-between gap-3 px-5 pt-4 pb-3">
          <div className="flex items-center gap-3">
            <div className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-primary text-xs font-bold text-primary-foreground">
              {index + 1}
            </div>
            <div>
              <h3 className="text-base font-semibold text-card-foreground">
                {visit.apartmentName}
              </h3>
              <p className="mt-0.5 text-sm text-muted-foreground">
                {visit.dong} {visit.ho}
              </p>
            </div>
          </div>
          <Badge variant="outline" className={`shrink-0 gap-1 ${statusBadgeClass(visit.appointmentStatus)}`}>
            <StatusIcon status={visit.appointmentStatus} />
            {visit.appointmentStatus}
          </Badge>
        </div>

        {/* Divider */}
        <div className="mx-5 border-t border-border/60" />

        {/* Details grid */}
        <div className="grid grid-cols-1 gap-3 px-5 pt-3 pb-4 sm:grid-cols-2">
          {/* Price */}
          <div className="flex items-center gap-2.5">
            <div className="flex size-7 shrink-0 items-center justify-center rounded-md bg-secondary">
              <span className="text-xs font-bold text-secondary-foreground">{"₩"}</span>
            </div>
            <div>
              <p className="text-[11px] font-medium tracking-wide text-muted-foreground">
                {"금액"}
              </p>
              <p className="text-sm font-semibold text-card-foreground">
                {visit.priceType} {visit.price}
              </p>
            </div>
          </div>

          {/* Visit Time */}
          <div className="flex items-center gap-2.5">
            <div className="flex size-7 shrink-0 items-center justify-center rounded-md bg-secondary">
              <Clock className="size-3.5 text-secondary-foreground" />
            </div>
            <div>
              <p className="text-[11px] font-medium tracking-wide text-muted-foreground">
                {"방문시간"}
              </p>
              <p className="text-sm font-semibold text-card-foreground">{visit.visitTime}</p>
            </div>
          </div>

          {/* Co-broker Agency */}
          <div className="flex items-center gap-2.5">
            <div className="flex size-7 shrink-0 items-center justify-center rounded-md bg-secondary">
              <Users className="size-3.5 text-secondary-foreground" />
            </div>
            <div>
              <p className="text-[11px] font-medium tracking-wide text-muted-foreground">
                {"공동중개 부동산"}
              </p>
              <p className="text-sm font-medium text-card-foreground">{visit.coBrokerAgency}</p>
            </div>
          </div>

          {/* Visit Location */}
          <div className="flex items-center gap-2.5">
            <div className="flex size-7 shrink-0 items-center justify-center rounded-md bg-secondary">
              <MapPin className="size-3.5 text-secondary-foreground" />
            </div>
            <div>
              <p className="text-[11px] font-medium tracking-wide text-muted-foreground">
                {"방문할 곳"}
              </p>
              <p className="text-sm font-medium text-card-foreground">{visit.apartmentName}</p>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="mx-5 border-t border-border/60" />

        {/* Phone numbers */}
        <div className="flex flex-col gap-2 px-5 pt-3 pb-4 sm:flex-row sm:items-center sm:gap-6">
          <a
            href={`tel:${visit.visitPhone}`}
            className="group/phone flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-accent"
          >
            <Phone className="size-3.5" />
            <span className="text-[11px] font-medium">{"방문처"}</span>
            <span className="font-semibold text-card-foreground group-hover/phone:text-accent">
              {visit.visitPhone}
            </span>
          </a>
          <a
            href={`tel:${visit.agencyPhone}`}
            className="group/phone flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-accent"
          >
            <Building className="size-3.5" />
            <span className="text-[11px] font-medium">{"부동산"}</span>
            <span className="font-semibold text-card-foreground group-hover/phone:text-accent">
              {visit.agencyPhone}
            </span>
          </a>
        </div>

        {/* Optional memo */}
        {visit.memo && (
          <>
            <div className="mx-5 border-t border-border/60" />
            <div className="px-5 pt-2.5 pb-4">
              <p className="rounded-md bg-muted/50 px-3 py-2 text-xs leading-relaxed text-muted-foreground">
                {visit.memo}
              </p>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  )
}
