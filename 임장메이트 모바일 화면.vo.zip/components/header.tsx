"use client"

import { Building2, Bell, User, Menu } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useState } from "react"

const navItems = [
  { label: "오늘 일정", href: "#", active: true },
  { label: "매물 관리", href: "#", active: false },
  { label: "고객 관리", href: "#", active: false },
  { label: "거래 현황", href: "#", active: false },
]

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 bg-primary text-primary-foreground">
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center rounded-lg bg-accent p-1.5">
              <Building2 className="size-5 text-accent-foreground" />
            </div>
            <div className="flex flex-col">
              <span className="text-base font-bold leading-tight tracking-tight">
                {"임장메이트"}
                <span className="ml-1 text-xs font-semibold opacity-80">PRO</span>
              </span>
              <span className="hidden text-[10px] font-light tracking-wide opacity-60 sm:block">
                {"공인중개사 매물 방문 관리"}
              </span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden items-center gap-1 md:flex" aria-label="주요 메뉴">
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                className={`rounded-md px-3 py-2 text-sm font-medium transition-colors ${
                  item.active
                    ? "bg-accent/20 text-primary-foreground"
                    : "text-primary-foreground/70 hover:bg-accent/10 hover:text-primary-foreground"
                }`}
              >
                {item.label}
              </a>
            ))}
          </nav>

          {/* Right Actions */}
          <div className="flex items-center gap-2">
            <button
              className="relative rounded-md p-2 text-primary-foreground/70 transition-colors hover:bg-accent/10 hover:text-primary-foreground"
              aria-label="알림"
            >
              <Bell className="size-5" />
              <Badge className="absolute -top-0.5 -right-0.5 flex size-4 items-center justify-center rounded-full border-0 bg-red-500 p-0 text-[10px] text-primary-foreground">
                3
              </Badge>
            </button>
            <button
              className="hidden rounded-md p-2 text-primary-foreground/70 transition-colors hover:bg-accent/10 hover:text-primary-foreground sm:block"
              aria-label="내 프로필"
            >
              <User className="size-5" />
            </button>
            <Button
              variant="ghost"
              size="icon"
              className="text-primary-foreground/70 hover:bg-accent/10 hover:text-primary-foreground md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label="메뉴 열기"
            >
              <Menu className="size-5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <nav className="border-t border-primary-foreground/10 px-4 pb-4 md:hidden" aria-label="모바일 메뉴">
          <div className="flex flex-col gap-1 pt-2">
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                className={`rounded-md px-3 py-2.5 text-sm font-medium transition-colors ${
                  item.active
                    ? "bg-accent/20 text-primary-foreground"
                    : "text-primary-foreground/70 hover:bg-accent/10 hover:text-primary-foreground"
                }`}
              >
                {item.label}
              </a>
            ))}
          </div>
        </nav>
      )}
    </header>
  )
}
