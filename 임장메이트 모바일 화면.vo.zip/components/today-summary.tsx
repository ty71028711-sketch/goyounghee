import { CalendarDays, CheckCircle2, Clock, AlertTriangle } from "lucide-react"

interface TodaySummaryProps {
  totalVisits: number
  confirmedCount: number
  pendingCount: number
  changeRequestCount: number
}

export function TodaySummary({
  totalVisits,
  confirmedCount,
  pendingCount,
  changeRequestCount,
}: TodaySummaryProps) {
  const stats = [
    {
      label: "전체 방문",
      value: totalVisits,
      icon: CalendarDays,
      color: "text-primary",
      bgColor: "bg-primary/10",
    },
    {
      label: "확정",
      value: confirmedCount,
      icon: CheckCircle2,
      color: "text-emerald-600",
      bgColor: "bg-emerald-50",
    },
    {
      label: "미확정",
      value: pendingCount,
      icon: Clock,
      color: "text-amber-600",
      bgColor: "bg-amber-50",
    },
    {
      label: "변경요청",
      value: changeRequestCount,
      icon: AlertTriangle,
      color: "text-red-500",
      bgColor: "bg-red-50",
    },
  ]

  return (
    <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
      {stats.map((stat) => (
        <div
          key={stat.label}
          className="flex items-center gap-3 rounded-xl border border-border/80 bg-card px-4 py-3"
        >
          <div className={`flex size-9 shrink-0 items-center justify-center rounded-lg ${stat.bgColor}`}>
            <stat.icon className={`size-4.5 ${stat.color}`} />
          </div>
          <div>
            <p className="text-[11px] font-medium text-muted-foreground">{stat.label}</p>
            <p className={`text-xl font-bold ${stat.color}`}>{stat.value}</p>
          </div>
        </div>
      ))}
    </div>
  )
}
