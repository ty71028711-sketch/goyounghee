import { Header } from "@/components/header"
import { PropertyVisitCard, type PropertyVisit } from "@/components/property-visit-card"
import { TodaySummary } from "@/components/today-summary"
import { ReportButton } from "@/components/report-button"
import { CalendarDays, Filter, ArrowUpDown } from "lucide-react"
import { Button } from "@/components/ui/button"

const todayVisits: PropertyVisit[] = [
  {
    id: 1,
    apartmentName: "래미안 퍼스티지",
    dong: "102동",
    ho: "1503호",
    price: "12억 5,000만",
    priceType: "매매",
    visitTime: "09:30",
    appointmentStatus: "확정",
    coBrokerAgency: "강남 센트럴부동산",
    visitPhone: "010-1234-5678",
    agencyPhone: "02-555-1234",
    memo: "집주인 직접 안내 예정. 주차 가능 확인 완료.",
  },
  {
    id: 2,
    apartmentName: "헬리오시티",
    dong: "84동",
    ho: "2201호",
    price: "18억 8,000만",
    priceType: "매매",
    visitTime: "11:00",
    appointmentStatus: "확정",
    coBrokerAgency: "송파 탑공인중개사",
    visitPhone: "010-9876-5432",
    agencyPhone: "02-413-9876",
  },
  {
    id: 3,
    apartmentName: "아크로리버파크",
    dong: "201동",
    ho: "3402호",
    price: "보증금 3억 / 월 250만",
    priceType: "전월세",
    visitTime: "13:30",
    appointmentStatus: "미확정",
    coBrokerAgency: "반포 우성공인중개사",
    visitPhone: "010-5555-1234",
    agencyPhone: "02-534-5555",
    memo: "세입자 일정 확인 중. 오후 재연락 필요.",
  },
  {
    id: 4,
    apartmentName: "잠실 엘스",
    dong: "108동",
    ho: "1102호",
    price: "16억 2,000만",
    priceType: "매매",
    visitTime: "15:00",
    appointmentStatus: "확정",
    coBrokerAgency: "잠실 나루공인중개사",
    visitPhone: "010-3333-4444",
    agencyPhone: "02-421-3333",
  },
  {
    id: 5,
    apartmentName: "디에이치 아너힐즈",
    dong: "301동",
    ho: "2805호",
    price: "보증금 5억 / 월 350만",
    priceType: "전월세",
    visitTime: "16:30",
    appointmentStatus: "변경요청",
    coBrokerAgency: "개포 리츠부동산",
    visitPhone: "010-7777-8888",
    agencyPhone: "02-459-7777",
    memo: "매도인측에서 17:00 이후로 변경 요청. 확인 필요.",
  },
  {
    id: 6,
    apartmentName: "래미안 원베일리",
    dong: "105동",
    ho: "4201호",
    price: "28억",
    priceType: "매매",
    visitTime: "17:30",
    appointmentStatus: "확정",
    coBrokerAgency: "서초 프라임부동산",
    visitPhone: "010-2222-3333",
    agencyPhone: "02-585-2222",
  },
]

function getFormattedDate() {
  const now = new Date()
  const year = now.getFullYear()
  const month = now.getMonth() + 1
  const date = now.getDate()
  const dayNames = ["일", "월", "화", "수", "목", "금", "토"]
  const day = dayNames[now.getDay()]
  return `${year}년 ${month}월 ${date}일 (${day})`
}

export default function HomePage() {
  const confirmedCount = todayVisits.filter((v) => v.appointmentStatus === "확정").length
  const pendingCount = todayVisits.filter((v) => v.appointmentStatus === "미확정").length
  const changeRequestCount = todayVisits.filter((v) => v.appointmentStatus === "변경요청").length

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="mx-auto max-w-7xl px-4 py-6 lg:px-8 lg:py-8">
        {/* Page Title + Report Button */}
        <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <div className="mb-1 flex items-center gap-2">
              <CalendarDays className="size-5 text-accent" />
              <span className="text-sm font-medium text-muted-foreground">
                {getFormattedDate()}
              </span>
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-foreground">
              {"오늘의 방문 일정"}
            </h1>
          </div>

          <ReportButton />
        </div>

        {/* Summary Stats */}
        <div className="mb-6">
          <TodaySummary
            totalVisits={todayVisits.length}
            confirmedCount={confirmedCount}
            pendingCount={pendingCount}
            changeRequestCount={changeRequestCount}
          />
        </div>

        {/* Toolbar */}
        <div className="mb-4 flex items-center justify-between">
          <p className="text-sm font-medium text-muted-foreground">
            {"총 "}
            <span className="font-bold text-foreground">{todayVisits.length}</span>
            {"건의 방문 예정"}
          </p>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="gap-1.5 text-xs">
              <Filter className="size-3.5" />
              {"필터"}
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5 text-xs">
              <ArrowUpDown className="size-3.5" />
              {"시간순"}
            </Button>
          </div>
        </div>

        {/* Visit Cards */}
        <div className="flex flex-col gap-4">
          {todayVisits.map((visit, index) => (
            <PropertyVisitCard key={visit.id} visit={visit} index={index} />
          ))}
        </div>

        {/* Footer */}
        <footer className="mt-12 border-t border-border/60 pt-6 pb-8 text-center">
          <p className="text-xs text-muted-foreground">
            {"임장메이트 PRO v1.0 | 공인중개사 전용 매물 방문 관리 시스템"}
          </p>
          <p className="mt-1 text-[11px] text-muted-foreground/60">
            {"Copyright 2026. 임장메이트. All rights reserved."}
          </p>
        </footer>
      </main>
    </div>
  )
}
